
const RunDemo = function (filemap)
{
	console.log("Initializing Demo");

	// get canvas, set dimensions to fill browser window
	const canvas = document.getElementById('the_canvas');
	canvas.width = window.innerWidth;
	canvas.height = window.innerHeight;

	// get WebGL context, confirm...
	const gl = canvas.getContext('webgl');

	if (!gl)
	{
		console.log('Browser is using experimental webgl.');
		gl = canvas.getContext('experimental-webgl');
	}

	if (!gl) {
		alert('This requires a browser which supports WebGL; Yours does not.');
	}

	// set background color and clear
	gl.clearColor(0.0, 0.0, 0.0, 1.0);
	gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

	// set up culling via depth and back face, set front face to CCW
	gl.enable(gl.DEPTH_TEST);
	gl.enable(gl.CULL_FACE);
	gl.frontFace(gl.CCW);
	gl.cullFace(gl.BACK);

	// create shaders
	const coloredRefractiveShader = createProgram(
		gl,
		filemap['coloredVertShaderText'],
		filemap['coloredFragShaderText']
	);

	const skyboxShader = createProgram(
		gl,
		filemap['skyboxVertShaderText'],
		filemap['skyboxFragShaderText']
	);

	//copied shader into program
	const uvProgram = createProgram(
		gl, 
		filemap['uvVertShaderText'],
		filemap['uvFragShaderText']
	);

	shaders = [
		coloredRefractiveShader,
		// add shaders other than skybox shader here.
		// some included shaders are unused.
		uvProgram
	];

	// set up camera
	const aspect = canvas.width / canvas.height;
	const fieldOfView = Math.PI / 4;
	const nearClip = 0.01;
	const farClip = 1000.0;
	const camera = new FPSCamera(
		gl,
		shaders,
		aspect,
		fieldOfView,
		nearClip,
		farClip,
		1 //place number here to change speed
	);
	camera.translate(new Vector(2, -2, 8));
	camera.lookAt(new Vector(0,0,0), new Vector(0, 1, 0));

	// set ambient light parameters
	const ambientLight = new Vector(0.5, 0.5, 0.5);

	// set up point lights' parameters
	const pointLightPosition = new Vector(0, 0, 0);
	const pointLightDiffuse = new Vector(1, 1, 1);
	const pointLightSpecular = new Vector(1, 1, 1);

	// use light manager to create lights
	const lightManager = new LightManager(
		gl,
		shaders,
		ambientLight
	);
	lightManager.addPointLight(pointLightPosition, pointLightDiffuse, pointLightSpecular);
	lightManager.addPointLight(pointLightPosition, pointLightDiffuse, pointLightSpecular);
	lightManager.update();

	// set up directional light's parameters and create directional light
	const directionalLightDirection = new Vector(1, -4, 2);
	const directionalLightDiffuse = new Vector(0.4, 0.7, 0.6);
	const directionalLightSpecular = new Vector(0.4, 0.7, 0.6);
	lightManager.addDirectionalLight(directionalLightDirection, directionalLightDiffuse, directionalLightSpecular);
	lightManager.update();

	// skybox
	const skyboxImageIDs = [
		'skybox-right',
		'skybox-left',
		'skybox-top',
		'skybox-bottom',
		'skybox-back',
		'skybox-front'
	];
	const skybox = new Skybox(gl, skyboxShader, skyboxImageIDs, camera);

	// set the the gate lighing
	const gateDiffuse = 0.1;
	const gateSpecular = 0.1;
	const gateAmbient = 0.9;
	const gateShininess = 0.7;

	// copied gate and plane in
	const gateTexture = new TexturedMaterial(
		gl,
		uvProgram,
		'toriiGate',
		true,
		gateDiffuse,
		gateSpecular,
		gateAmbient,
		gateShininess
	);

	//get the model info
	const gateModel = parseObjText(filemap['toriiGate']);
	//have an array of 3 and fill it
	const gateArray = {}
	let startZ = 0; //start at 0
	for(let index = 0; index < 10; index++)
	{
		gateArray[index] = new UVMesh(
			gl,
			gateModel.positions,
			gateModel.normals,
			gateModel.index,
			gateModel.texcoords,
			gateTexture
		);
		gateArray[index].translate(new Vector(0,0,startZ));
		startZ = startZ - 10; //shift the start
	}

	// textured earth material properties
	const retroPyramidDiffuse = 0.1;
	const retroPyramidSpecular = 0.1;
	const retroPyramidAmbient = 0.9;
	const retroPyramidShininess = 0.7;

	// create material for earth
	const retroPyramidTexture = new UVMaterial(
		gl,
		uvProgram,
		'retroPyramidTexture',
		true,
		retroPyramidDiffuse,
		retroPyramidSpecular,
		retroPyramidAmbient,
		retroPyramidShininess
	);

	const retroPyramid = parseObjText(filemap['retroPyramid']);
	const pyramindArray = {};
	const pyramindArrayStart = {};
	startZ = 0;
	for(let index = 0; index < 50; index++)
	{
			pyramindArray[index] = new UVMesh(
			gl,
			retroPyramid.positions,
			retroPyramid.normals,
			retroPyramid.index,
			retroPyramid.texcoords,
			retroPyramidTexture);
			let randX = Math.random()*50;
		
			if(pyramindArray[index].position.x < 15 || pyramindArray[index].position.x > -15)
				randX = (randX + 15);

			if(index %2 == 0)
				randX = randX * -1;

			pyramindArray[index].translate(new Vector(randX,1.5,startZ));
			pyramindArrayStart[index]=new Vector(randX,1.5,startZ);
			startZ =startZ-5;
	}

	startZ=0;

	const stoneLampDiffuse = 0.1;
	const stoneLampSpecular = 0.1;
	const stoneLampAmbient = 0.9;
	const stoneLampShininess = 0.7;

	// create material for earth
	const stoneLampTexture = new UVMaterial(
		gl,
		uvProgram,
		'lamp',
		true,
		stoneLampDiffuse,
		stoneLampSpecular,
		stoneLampAmbient,
		stoneLampShininess
	);

	
	const stoneLampModel = parseObjText(filemap['lamp']);
	const lampArrayRight = {};
	const lampArrayRightResetPos = {};
	for(let index = 0; index < 10; index++)
	{
		lampArrayRight[index] =  new UVMesh(
			gl,
			stoneLampModel.positions,
			stoneLampModel.normals,
			stoneLampModel.index,
			stoneLampModel.texcoords,
			stoneLampTexture
		);
		let lampAndStarXPosition = 12;
			
		lampArrayRight[index].translate(new Vector(lampAndStarXPosition,0.5,startZ));
		lampArrayRightResetPos[index] = new Vector(lampAndStarXPosition,0.5,startZ);
		startZ = startZ - 10;
	}

	startZ = 0
	const lampArrayLeft = {};
	const lampArrayLeftResetPos = {};
		for(let index = 0; index < 10; index++)
		{
			lampArrayLeft[index] =  new UVMesh(
				gl,
				stoneLampModel.positions,
				stoneLampModel.normals,
				stoneLampModel.index,
				stoneLampModel.texcoords,
				stoneLampTexture
			);
			let lampAndStarXPosition = -12;
				
			lampArrayLeft[index].translate(new Vector(lampAndStarXPosition,0.5,startZ));
			lampArrayLeftResetPos[index] = new Vector(lampAndStarXPosition,0.5,startZ);
			startZ = startZ - 10;
	}

	const starDiffuse = 0.1;
	const starSpecular = 0.1;
	const starAmbient = 0.9;
	const starShininess = 0.7;

	const starTexture = new UVMaterial(
		gl,
		uvProgram,
		'star',
		true,
		starDiffuse,
		starSpecular,
		starAmbient,
		starShininess
	);

	startZ =0;
	const starModel = parseObjText(filemap['star']);
	const starArray = {};
	const starArrayResetPos = {};
	for(let index = 0; index < 10; index++)
	{
		starArray[index] =  new UVMesh(
			gl,
			starModel.positions,
			starModel.normals,
			starModel.index,
			starModel.texcoords,
			starTexture
		);
			
		starArray[index].translate(new Vector(0,15,startZ));
		starArrayResetPos[index] = new Vector(0,15,startZ);
		startZ = startZ - 10;
	}
			
	const planeDiffuse = 0.1;
	const planeSpecular = 0.1;
	const planeAmbient = 0.9;
	const planeShininess = 0.7;

	const planeTexture = new UVMaterial(
		gl,
		uvProgram,
		'plane',
		true,
		planeDiffuse,
		planeSpecular,
		planeAmbient,
		planeShininess
	);

	const planeModel = parseObjText(filemap['plane']);
	const plane = new UVMesh(
		gl,
		planeModel.positions,
		planeModel.normals,
		planeModel.index,
		planeModel.texcoords,
		planeTexture
	);
	plane.translate(new Vector(0,0.1,0));

	// set up some arbitrary constants for motion
	const startTime = Date.now();
	let time;
	let k_theta = 1/1000;
	let k_alpha = 1/3101;
	let hr = 5;
	let vr = 2;
	let theta;
	let alpha;
	let cosTheta;
	let lightPosition;

	//USE VECTORS ON TRANSLATE AND SCALE
	//0.05
	const movebackward = new Vector(0,0,0.05);
	const resetPosition = new Vector(0,0,-70);

	var main = function()
	{
		gl.clear(gl.DEPTH_BUFFER_BIT | gl.COLOR_BUFFER_BIT);

		time = Date.now() - startTime;
		theta = time * k_theta;
		alpha = time * k_alpha;
		cosTheta = Math.cos(theta);

		lightPosition = new Vector(
			hr*cosTheta*Math.sin(alpha),
			vr*Math.sin(2*theta),
			vr*cosTheta*Math.cos(alpha)
		);

		lightManager.pointLights[0].setPosition(lightPosition);
		lightManager.pointLights[1].setPosition(lightPosition.inverse())
		lightManager.update();

		camera.update();
		skybox.draw();

		//draw each gate
		for(let gateIndex = 0; gateIndex < 10; gateIndex++)
		{
			gateArray[gateIndex].translate(movebackward); //move the gates forward 
			if(gateArray[gateIndex].position.z > 30) //check if the Z position is past 30
				gateArray[gateIndex].setPosition(resetPosition); //reset the position to be at something
			gateArray[gateIndex].draw();//draw the object
		}
		

		for(let pyramindIndex = 0; pyramindIndex < 50; pyramindIndex++)
		{
			let randX = Math.random()*5;
			if(pyramindArray[pyramindIndex].position.x < 5 || pyramindArray[pyramindIndex].position.x > -5)
				if(pyramindIndex %2 == 0)
					randX = (randX -5) * -10;


			pyramindArray[pyramindIndex].translate(movebackward);
			if(pyramindArray[pyramindIndex].position.z >40)
				pyramindArray[pyramindIndex].setPosition(pyramindArrayStart[pyramindIndex]);
			pyramindArray[pyramindIndex].draw();
		}

		for(let index = 0; index < 10; index++)
		{
			lampArrayRight[index].translate(movebackward); //move the gates forward 
			if(lampArrayRight[index].position.z > 30) //check if the Z position is past 30
				lampArrayRight[index].setPosition(lampArrayRightResetPos[index]); //reset the position to be at something
		
			lampArrayLeft[index].translate(movebackward); //move the gates forward 
			if(lampArrayLeft[index].position.z > 30) //check if the Z position is past 30
			{
				lampArrayLeft[index].setPosition(lampArrayLeftResetPos[index]); //reset the position to be at something
			}
			
			starArray[index].translate(movebackward);
			if(starArray[index].position.z > 30)
			{
				starArray[index].setPosition(starArrayResetPos[index]);
			}
			starArray[index].draw();
			lampArrayLeft[index].draw();
			lampArrayRight[index].draw();
		}
		
		plane.draw();

		requestAnimationFrame(main);
	}
	requestAnimationFrame(main);
}

var InitDemo = function()
{
	const imports = [
		['suzyOBJ', 'models/suzy.obj'],
		['coloredVertShaderText', 'shaders/vert.coloredRefractive.glsl'],
		['coloredFragShaderText', 'shaders/frag.coloredRefractive.glsl'],
		['skyboxVertShaderText', 'shaders/vert.skybox.glsl'],
		['skyboxFragShaderText', 'shaders/frag.skybox.glsl'],
		// TODO continue //rename
		['uvVertShaderText', 'shaders/vert.textured.glsl'],
		['uvFragShaderText', 'shaders/frag.textured.glsl'],
		['retroPyramid','models/retroPyramid2.obj'],
		['toriiGate','models/ToriiGate.obj'],
		['80sback','models/80sBackground.obj'],
		['lamp','models/stoneLamp.obj'],
		['plane','models/plane.obj'],
		['star','models/prismStar.obj'],
		['rectangel','models/80sRectangle.obj']
	]
	
	const importer = new resourceImporter(imports, RunDemo);
}